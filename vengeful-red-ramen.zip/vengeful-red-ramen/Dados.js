export const info = [
  {
    nome: "CyberPioneers",
    descricao: "Grupo dedicado a explorar as fronteiras da tecnologia e inteligência artificial.",
    integrantes: ["Rafael ", "Gabriela ", "André ", "Isabela "]
  },
  {
    nome: "GreenInnovators",
    descricao: "Iniciativas focadas em soluções ecológicas e inovação sustentável.",
    integrantes: ["Lucas ", "Larissa ", "Eduardo ", "Monique "]
  },
  {
    nome: "CreativeMinds",
    descricao: "Exploração criativa das artes visuais, música e design.",
    integrantes: ["Felipe ", "Lúcia ", "Thiago ", "Carolina "]
  },
  {
    nome: "CodeMasters",
    descricao: "Grupo de desenvolvedores apaixonados por programação e desafios tecnológicos.",
    integrantes: ["Marcelo ", "Patrícia ", "Júlio ", "Alice "]
  },
  {
    nome: "EliteGamers",
    descricao: "Comunidadade de jogadores que buscam o alto nível competitivo em jogos online.",
    integrantes: ["Bruno ", "Raquel ", "Victor ", "Sofia "]
  },
];
